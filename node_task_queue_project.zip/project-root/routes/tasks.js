const express = require('express');
const config = require('../config');
const taskQueue = require('../taskQueue');

module.exports = (redisClient, taskQueue) => {
    const router = express.Router();

    router.post('/', async (req, res) => {
        const { user_id: userId } = req.body;

        if (!userId) {
            return res.status(400).json({ error: 'user_id is required' });
        }

        try {
            await taskQueue.addTaskToQueue(userId, redisClient);
            res.status(200).json({ message: 'Task added to queue' });
        } catch (error) {
            res.status(500).json({ error: 'Server error' });
        }
    });

    return router;
};